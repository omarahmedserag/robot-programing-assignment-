#!/usr/bin/env python3
"""
CMP9767 – Inventory Aggregator (FINAL + DISTANCE-GATED VERSION)
✔ Counts each physical object exactly once
✔ Uses temporal majority voting for class correctness
✔ Persistent inventory (never removes objects)
✔ Robust spatial data association
✔ Distance-gated confirmation (≤ 1.4 m from robot)
✔ RViz markers + CSV export
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PoseArray, Pose, Vector3
from std_msgs.msg import ColorRGBA, Header
from visualization_msgs.msg import Marker, MarkerArray
from tf2_ros import Buffer, TransformListener
import math
import csv
from collections import defaultdict


class InventoryAggregator(Node):
    def __init__(self):
        super().__init__('inventory_aggregator')

        # ---------------- PARAMETERS ----------------
        self.association_radius = 0.7
        self.confirm_radius = 0.8
        self.min_observations = 7
        self.max_detection_distance = 1.4  # 🔴 NEW
        self.export_path = 'inventory_report.csv'
        self.map_frame = 'map'
        self.robot_frame = 'base_link'

        # ---------------- TF ----------------
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # ---------------- ROS ----------------
        self.create_subscription(
            PoseStamped,
            '/emergency_detections',
            self.detection_callback,
            10
        )
        self.pose_pub = self.create_publisher(PoseArray, '/confirmed_objects', 10)
        self.marker_pub = self.create_publisher(MarkerArray, '/inventory_markers', 10)

        # ---------------- STATE ----------------
        self.inventory = []
        self.candidates = []

        self.get_logger().info("Inventory Aggregator – DISTANCE-GATED VERSION RUNNING")

    # ============================================================
    # HELPERS
    # ============================================================

    def _distance_xy(self, p1, p2):
        return math.hypot(
            p1.position.x - p2.position.x,
            p1.position.y - p2.position.y
        )

    def _get_robot_pose(self):
        try:
            tf = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.robot_frame,
                rclpy.time.Time()
            )
            pose = Pose()
            pose.position.x = tf.transform.translation.x
            pose.position.y = tf.transform.translation.y
            pose.position.z = tf.transform.translation.z
            return pose
        except Exception:
            return None

    def _within_robot_distance(self, object_pose):
        robot_pose = self._get_robot_pose()
        if robot_pose is None:
            return False
        dist = self._distance_xy(robot_pose, object_pose)
        return dist <= self.max_detection_distance

    def _belongs_to_inventory(self, pose):
        for obj in self.inventory:
            if self._distance_xy(obj['pose'], pose) < self.association_radius:
                return True
        return False

    def _find_candidate(self, pose):
        for cand in self.candidates:
            if self._distance_xy(cand['pose_mean'], pose) < self.confirm_radius:
                return cand
        return None

    # ============================================================
    # CALLBACK
    # ============================================================

    def detection_callback(self, msg: PoseStamped):
        obj_class = msg.header.frame_id
        if obj_class not in {'fire_extinguisher', 'first_aid_kit'}:
            return

        # 🔴 Distance gate (NEW)
        if not self._within_robot_distance(msg.pose):
            return

        # Ignore known objects
        if self._belongs_to_inventory(msg.pose):
            return

        candidate = self._find_candidate(msg.pose)
        if candidate is None:
            candidate = {
                'poses': [],
                'class_votes': defaultdict(int),
                'pose_mean': msg.pose
            }
            self.candidates.append(candidate)

        candidate['poses'].append(msg.pose)
        candidate['class_votes'][obj_class] += 1
        self._update_candidate_mean(candidate)

        if len(candidate['poses']) >= self.min_observations:
            self._confirm_candidate(candidate)

        self._publish_results()

    # ============================================================
    # CANDIDATE MANAGEMENT
    # ============================================================

    def _update_candidate_mean(self, candidate):
        xs = [p.position.x for p in candidate['poses']]
        ys = [p.position.y for p in candidate['poses']]
        zs = [p.position.z for p in candidate['poses']]
        candidate['pose_mean'] = Pose()
        candidate['pose_mean'].position.x = sum(xs) / len(xs)
        candidate['pose_mean'].position.y = sum(ys) / len(ys)
        candidate['pose_mean'].position.z = sum(zs) / len(zs)
        candidate['pose_mean'].orientation.w = 1.0

    def _confirm_candidate(self, candidate):
        final_class = max(candidate['class_votes'], key=candidate['class_votes'].get)
        self.inventory.append({
            'pose': candidate['pose_mean'],
            'class': final_class
        })
        self.get_logger().info(
            f"CONFIRMED {final_class} at "
            f"({candidate['pose_mean'].position.x:.2f}, "
            f"{candidate['pose_mean'].position.y:.2f})"
        )
        self.candidates.remove(candidate)

    # ============================================================
    # PUBLISHING
    # ============================================================

    def _publish_results(self):
        header = Header()
        header.frame_id = 'map'
        header.stamp = self.get_clock().now().to_msg()

        pose_array = PoseArray(header=header)
        for obj in self.inventory:
            pose_array.poses.append(obj['pose'])
        self.pose_pub.publish(pose_array)

        markers = MarkerArray()
        for i, obj in enumerate(self.inventory):
            is_ext = obj['class'] == 'fire_extinguisher'
            m = Marker()
            m.header = header
            m.ns = 'inventory'
            m.id = i
            m.type = Marker.CUBE
            m.action = Marker.ADD
            m.pose = obj['pose']
            m.scale = Vector3()
            m.scale.x = 0.25
            m.scale.y = 0.25
            m.scale.z = 0.5 if is_ext else 0.25
            m.color = ColorRGBA(
                r=1.0 if is_ext else 0.0,
                g=0.0 if is_ext else 1.0,
                b=0.0,
                a=0.85
            )
            markers.markers.append(m)
        self.marker_pub.publish(markers)

    # ============================================================
    # SHUTDOWN
    # ============================================================

    def destroy_node(self):
        try:
            with open(self.export_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['class', 'x', 'y', 'z'])
                for obj in self.inventory:
                    p = obj['pose'].position
                    writer.writerow([obj['class'], p.x, p.y, p.z])
            self.get_logger().info(f"Inventory saved to {self.export_path}")
        except Exception as e:
            self.get_logger().error(f"CSV export failed: {e}")
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = InventoryAggregator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()