#!/usr/bin/env python3
import math
import time
from typing import Optional, Tuple

import cv2
import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy

from sensor_msgs.msg import Image, CameraInfo
from geometry_msgs.msg import PointStamped
from std_msgs.msg import String
from cv_bridge import CvBridge

from ultralytics import YOLO


TARGET_CLASSES = {"fire_extinguisher", "first_aid_kit"}


def depth_to_meters(depth_img: np.ndarray) -> np.ndarray:
    """
    Convert depth image to meters.
    Supports:
      - 16UC1 in millimeters
      - 32FC1 in meters
    """
    if depth_img.dtype == np.uint16:
        return depth_img.astype(np.float32) / 1000.0
    return depth_img.astype(np.float32)


class YoloSafetyDetector(Node):
    """
    YOLOv8-based safety detector for ROS2:
    - Subscribes to RGB + depth + camera_info
    - Runs YOLO inference on RGB
    - Filters classes (fire_extinguisher, first_aid_kit)
    - Computes 3D position using depth + intrinsics
    - Publishes:
        * /perception/safety/debug_image (Image)
        * /perception/safety/target_point (PointStamped)
        * /perception/safety/target_text (String)
    - Optionally shows an OpenCV window
    """

    def __init__(self):
        super().__init__("yolo_safety_detector")

        # ---------------- Parameters ----------------
        self.declare_parameter("model_path", "")
        self.declare_parameter("device", "cpu")          # "cpu" or "cuda:0"
        self.declare_parameter("conf", 0.25)
        self.declare_parameter("imgsz", 640)
        self.declare_parameter("show_window", True)
        self.declare_parameter("window_name", "YOLO Safety Detector")
        self.declare_parameter("rgb_topic", "/limo/depth_camera_link/image_raw")
        self.declare_parameter("depth_topic", "/limo/depth_camera_link/depth/image_raw")
        self.declare_parameter("camera_info_topic", "/limo/depth_camera_link/camera_info")
        self.declare_parameter("target_frame", "limo/depth_camera_link")  # or "base_link" later if you transform

        self.model_path = self.get_parameter("model_path").get_parameter_value().string_value
        self.device = self.get_parameter("device").get_parameter_value().string_value
        self.conf = float(self.get_parameter("conf").value)
        self.imgsz = int(self.get_parameter("imgsz").value)
        self.show_window = bool(self.get_parameter("show_window").value)
        self.window_name = self.get_parameter("window_name").get_parameter_value().string_value

        self.rgb_topic = self.get_parameter("rgb_topic").get_parameter_value().string_value
        self.depth_topic = self.get_parameter("depth_topic").get_parameter_value().string_value
        self.cam_info_topic = self.get_parameter("camera_info_topic").get_parameter_value().string_value
        self.target_frame = self.get_parameter("target_frame").get_parameter_value().string_value

        if not self.model_path:
            self.get_logger().error("Parameter 'model_path' is empty. Set it to your best.pt path.")
            raise RuntimeError("model_path not set")

        # ---------------- Load YOLO ----------------
        self.get_logger().info(f"Loading YOLO model: {self.model_path}")
        self.model = YOLO(self.model_path)
        self.get_logger().info(f"YOLO loaded. Device={self.device}, conf={self.conf}, imgsz={self.imgsz}")

        # ---------------- ROS IO ----------------
        qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=5
        )

        self.bridge = CvBridge()

        self.last_depth_m: Optional[np.ndarray] = None
        self.last_cam_info: Optional[CameraInfo] = None
        self.last_depth_stamp = None
        self.last_rgb_stamp = None

        self.sub_rgb = self.create_subscription(Image, self.rgb_topic, self.on_rgb, qos)
        self.sub_depth = self.create_subscription(Image, self.depth_topic, self.on_depth, qos)
        self.sub_info = self.create_subscription(CameraInfo, self.cam_info_topic, self.on_camera_info, qos)

        self.pub_debug = self.create_publisher(Image, "/perception/safety/debug_image", 10)
        self.pub_point = self.create_publisher(PointStamped, "/perception/safety/target_point", 10)
        self.pub_text = self.create_publisher(String, "/perception/safety/target_text", 10)

        if self.show_window:
            cv2.namedWindow(self.window_name, cv2.WINDOW_NORMAL)

        self.get_logger().info("YOLO Safety Detector node started.")

    def on_camera_info(self, msg: CameraInfo):
        self.last_cam_info = msg

    def on_depth(self, msg: Image):
        try:
            # depth is usually 16UC1 or 32FC1
            depth = self.bridge.imgmsg_to_cv2(msg, desired_encoding="passthrough")
            self.last_depth_m = depth_to_meters(depth)
            self.last_depth_stamp = msg.header.stamp
        except Exception as e:
            self.get_logger().warn(f"Depth conversion failed: {e}")

    def on_rgb(self, msg: Image):
        self.last_rgb_stamp = msg.header.stamp

        if self.last_cam_info is None or self.last_depth_m is None:
            # Wait until depth + intrinsics arrive
            return

        # Convert RGB image
        try:
            bgr = self.bridge.imgmsg_to_cv2(msg, desired_encoding="bgr8")
        except Exception as e:
            self.get_logger().warn(f"RGB conversion failed: {e}")
            return

        # Run YOLO inference
        t0 = time.time()
        results = self.model.predict(
            source=bgr,
            conf=self.conf,
            imgsz=self.imgsz,
            device=self.device,
            verbose=False
        )
        dt = (time.time() - t0) * 1000.0

        annotated = bgr.copy()

        # Camera intrinsics
        fx = self.last_cam_info.k[0]
        fy = self.last_cam_info.k[4]
        cx = self.last_cam_info.k[2]
        cy = self.last_cam_info.k[5]

        # Get best target among allowed classes
        best = self.select_best_target(results, annotated, fx, fy, cx, cy)

        # Publish debug image
        debug_msg = self.bridge.cv2_to_imgmsg(annotated, encoding="bgr8")
        debug_msg.header = msg.header
        self.pub_debug.publish(debug_msg)

        # Show window (if available)
        if self.show_window:
            cv2.imshow(self.window_name, annotated)
            cv2.waitKey(1)

        # Print performance line (academic + useful)
        self.get_logger().info(f"Inference: {dt:.1f} ms | targets: {best[0] if best else 'none'}")

    def select_best_target(
        self,
        results,
        annotated: np.ndarray,
        fx: float, fy: float, cx: float, cy: float
    ) -> Optional[Tuple[str, float, Tuple[int, int, int, int], Tuple[float, float, float]]]:
        """
        Returns best target as:
          (class_name, conf, (x1,y1,x2,y2), (X,Y,Z)) in camera frame
        """
        if not results or len(results) == 0:
            return None

        r0 = results[0]
        names = r0.names

        # YOLOv8 boxes
        if r0.boxes is None or len(r0.boxes) == 0:
            return None

        best_item = None
        best_conf = -1.0

        h, w = annotated.shape[:2]
        depth_m = self.last_depth_m
        if depth_m is None:
            return None

        for b in r0.boxes:
            cls_id = int(b.cls.item())
            conf = float(b.conf.item())
            cls_name = names.get(cls_id, str(cls_id))

            if cls_name not in TARGET_CLASSES:
                continue

            x1, y1, x2, y2 = map(int, b.xyxy[0].tolist())
            x1 = max(0, min(x1, w - 1))
            x2 = max(0, min(x2, w - 1))
            y1 = max(0, min(y1, h - 1))
            y2 = max(0, min(y2, h - 1))

            # center pixel
            u = int((x1 + x2) / 2)
            v = int((y1 + y2) / 2)

            z = float(depth_m[v, u])
            if not np.isfinite(z) or z <= 0.0:
                # Try local patch median if center is invalid
                z = self.median_depth(depth_m, u, v, radius=3)

            if z is None:
                # cannot compute 3D, but still draw box
                self.draw_box(annotated, x1, y1, x2, y2, f"{cls_name} {conf:.2f}", (0, 0, 255))
                continue

            X = (u - cx) * z / fx
            Y = (v - cy) * z / fy
            Z = z

            # Choose the highest-confidence among target classes
            if conf > best_conf:
                best_conf = conf
                best_item = (cls_name, conf, (x1, y1, x2, y2), (X, Y, Z))

            # Draw
            self.draw_box(annotated, x1, y1, x2, y2, f"{cls_name} {conf:.2f}", (0, 255, 0))
            self.draw_point_text(annotated, u, v, X, Y, Z)

            # Publish each target detection text + point (you can change this later)
            self.publish_target(cls_name, conf, X, Y, Z)

        return best_item

    def median_depth(self, depth_m: np.ndarray, u: int, v: int, radius: int = 3) -> Optional[float]:
        h, w = depth_m.shape[:2]
        u1, u2 = max(0, u - radius), min(w - 1, u + radius)
        v1, v2 = max(0, v - radius), min(h - 1, v + radius)
        patch = depth_m[v1:v2 + 1, u1:u2 + 1].reshape(-1)
        patch = patch[np.isfinite(patch)]
        patch = patch[patch > 0.0]
        if patch.size == 0:
            return None
        return float(np.median(patch))

    def publish_target(self, cls_name: str, conf: float, X: float, Y: float, Z: float):
        # PointStamped
        p = PointStamped()
        p.header.frame_id = self.target_frame
        p.header.stamp = self.get_clock().now().to_msg()
        p.point.x = float(X)
        p.point.y = float(Y)
        p.point.z = float(Z)
        self.pub_point.publish(p)

        # Text
        s = String()
        s.data = f"{cls_name} conf={conf:.2f} pos=[{X:.2f}, {Y:.2f}, {Z:.2f}] m"
        self.pub_text.publish(s)

        # Also print (academic log)
        self.get_logger().info(s.data)

    @staticmethod
    def draw_box(img, x1, y1, x2, y2, label, color):
        cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
        cv2.putText(img, label, (x1, max(0, y1 - 5)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

    @staticmethod
    def draw_point_text(img, u, v, X, Y, Z):
        cv2.circle(img, (u, v), 4, (255, 255, 255), -1)
        txt = f"({X:.2f},{Y:.2f},{Z:.2f})m"
        cv2.putText(img, txt, (u + 6, v + 6),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)


def main():
    rclpy.init()
    node = YoloSafetyDetector()
    try:
        rclpy.spin(node)
    finally:
        if node.show_window:
            cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()

