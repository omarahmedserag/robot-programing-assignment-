#!/usr/bin/env python3
"""
CMP9767 – Inventory Aggregator (FINAL + DISTANCE-GATED + CLEAN OUTPUT)

✔ Counts each physical object exactly once  
✔ Temporal majority voting with class dominance  
✔ Persistent inventory  
✔ Robust spatial data association  
✔ Distance-gated confirmation (≤ 2.25 m from robot)  
✔ ROS 2 Humble–safe message usage  
✔ RViz markers + CSV export  
✔ Clean terminal table output  
✔ Final plot at shutdown (no runtime impact)
"""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, PoseArray, Pose, Vector3
from std_msgs.msg import ColorRGBA, Header
from visualization_msgs.msg import Marker, MarkerArray
from tf2_ros import Buffer, TransformListener
import math
import csv
from collections import defaultdict
import os

# Import matplotlib ONLY for shutdown (safe)
try:
    import matplotlib.pyplot as plt
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False


class InventoryAggregator(Node):

    def __init__(self):
        super().__init__('inventory_aggregator')

        # ---------------- PARAMETERS ----------------
        self.association_radius = 2.2
        self.confirm_radius = 1.65
        self.min_observations = 5
        self.class_dominance = 0.7
        self.max_detection_distance = 2.25
        self.export_path = 'inventory_report.csv'
        self.plot_path = 'inventory_plot.png'

        self.map_frame = 'map'
        self.robot_frame = 'base_link'

        # ---------------- TF ----------------
        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # ---------------- ROS ----------------
        self.create_subscription(
            PoseStamped,
            '/emergency_detections',
            self.detection_callback,
            10
        )

        self.pose_pub = self.create_publisher(PoseArray, '/confirmed_objects', 10)
        self.marker_pub = self.create_publisher(MarkerArray, '/inventory_markers', 10)

        # ---------------- STATE ----------------
        self.inventory = []
        self.candidates = []

        self.get_logger().info("Inventory Aggregator – CLEAN OUTPUT + SAFE PLOTTING")

    # ============================================================
    # HELPERS
    # ============================================================

    def _distance_xy(self, p1, p2):
        return math.hypot(p1.position.x - p2.position.x, p1.position.y - p2.position.y)

    def _get_robot_pose(self):
        try:
            # Use zero timeout to avoid waiting
            tf = self.tf_buffer.lookup_transform(
                self.map_frame,
                self.robot_frame,
                rclpy.time.Time(),  # latest available
                timeout=rclpy.duration.Duration(seconds=0.1)
            )
            pose = Pose()
            pose.position.x = tf.transform.translation.x
            pose.position.y = tf.transform.translation.y
            pose.position.z = tf.transform.translation.z
            pose.orientation.w = 1.0
            return pose
        except Exception:
            return None

    def _within_robot_distance(self, object_pose):
        robot_pose = self._get_robot_pose()
        if robot_pose is None:
            return False
        return self._distance_xy(robot_pose, object_pose) <= self.max_detection_distance

    def _belongs_to_inventory(self, pose):
        for obj in self.inventory:
            if self._distance_xy(obj['pose'], pose) < self.association_radius:
                return True
        return False

    def _find_candidate(self, pose):
        for cand in self.candidates:
            if self._distance_xy(cand['pose_mean'], pose) < self.confirm_radius:
                return cand
        return None

    def _print_inventory_summary(self):
        total = len(self.inventory)
        class_counts = defaultdict(int)
        for obj in self.inventory:
            class_counts[obj['class']] += 1

        # Build clean table
        headers = ["CLASS", "COUNT"]
        col_widths = [20, 8]
        separator = "-" * (sum(col_widths) + 3)

        lines = []
        lines.append("INVENTORY SUMMARY")
        lines.append(separator)
        lines.append(f"{'CLASS':<{col_widths[0]}} | {'COUNT':>{col_widths[1]}}")
        lines.append(separator)

        for cls in sorted(class_counts.keys()):
            lines.append(f"{cls:<{col_widths[0]}} | {class_counts[cls]:>{col_widths[1]}}")
        
        lines.append(separator)
        lines.append(f"{'TOTAL':<{col_widths[0]}} | {total:>{col_widths[1]}}")

        for line in lines:
            self.get_logger().info(line)

    # ============================================================
    # CALLBACK
    # ============================================================

    def detection_callback(self, msg: PoseStamped):
        obj_class = msg.header.frame_id
        if obj_class not in {'fire_extinguisher', 'first_aid_kit'}:
            return

        if not self._within_robot_distance(msg.pose):
            return

        if self._belongs_to_inventory(msg.pose):
            return

        candidate = self._find_candidate(msg.pose)

        if candidate is None:
            candidate = {
                'poses': [],
                'class_votes': defaultdict(int),
                'pose_mean': msg.pose
            }
            self.candidates.append(candidate)

        candidate['poses'].append(msg.pose)
        candidate['class_votes'][obj_class] += 1
        self._update_candidate_mean(candidate)

        if len(candidate['poses']) >= self.min_observations:
            self._confirm_candidate(candidate)

        self._publish_results()

    # ============================================================
    # CANDIDATE MANAGEMENT
    # ============================================================

    def _update_candidate_mean(self, candidate):
        xs = [p.position.x for p in candidate['poses']]
        ys = [p.position.y for p in candidate['poses']]
        zs = [p.position.z for p in candidate['poses']]

        pose = Pose()
        pose.position.x = sum(xs) / len(xs)
        pose.position.y = sum(ys) / len(ys)
        pose.position.z = sum(zs) / len(zs)
        pose.orientation.w = 1.0
        candidate['pose_mean'] = pose

    def _confirm_candidate(self, candidate):
        votes = candidate['class_votes']
        total = sum(votes.values())
        final_class, max_votes = max(votes.items(), key=lambda x: x[1])

        if max_votes / total < self.class_dominance:
            return

        self.inventory.append({
            'pose': candidate['pose_mean'],
            'class': final_class
        })

        self.get_logger().info(
            f"CONFIRMED {final_class} at "
            f"({candidate['pose_mean'].position.x:.2f}, "
            f"{candidate['pose_mean'].position.y:.2f})"
        )

        self._print_inventory_summary()
        self.candidates.remove(candidate)

    # ============================================================
    # PUBLISHING
    # ============================================================

    def _publish_results(self):
        header = Header()
        header.frame_id = self.map_frame
        header.stamp = self.get_clock().now().to_msg()

        pose_array = PoseArray()
        pose_array.header = header
        for obj in self.inventory:
            pose_array.poses.append(obj['pose'])
        self.pose_pub.publish(pose_array)

        markers = MarkerArray()
        for i, obj in enumerate(self.inventory):
            is_ext = obj['class'] == 'fire_extinguisher'
            m = Marker()
            m.header = header
            m.ns = 'inventory'
            m.id = i
            m.type = Marker.CUBE
            m.action = Marker.ADD
            m.pose = obj['pose']
            m.scale = Vector3(x=0.25, y=0.25, z=0.5 if is_ext else 0.25)
            m.color = ColorRGBA(r=1.0 if is_ext else 0.0, g=0.0 if is_ext else 1.0, b=0.0, a=0.85)
            markers.markers.append(m)

        self.marker_pub.publish(markers)

    # ============================================================
    # SHUTDOWN + FINAL PLOT (SAFE)
    # ============================================================

    def destroy_node(self):
        # --- Save CSV ---
        try:
            with open(self.export_path, 'w', newline='') as f:
                writer = csv.writer(f)
                writer.writerow(['class', 'x', 'y', 'z'])
                for obj in self.inventory:
                    p = obj['pose'].position
                    writer.writerow([obj['class'], p.x, p.y, p.z])
            self.get_logger().info(f"Inventory saved to {self.export_path}")
        except Exception as e:
            self.get_logger().error(f"CSV export failed: {e}")

        # --- Generate FINAL plot (only once, at shutdown) ---
        if MATPLOTLIB_AVAILABLE and self.inventory:
            try:
                fire_x, fire_y = [], []
                first_x, first_y = [], []

                for obj in self.inventory:
                    x = obj['pose'].position.x
                    y = obj['pose'].position.y
                    if obj['class'] == 'fire_extinguisher':
                        fire_x.append(x)
                        fire_y.append(y)
                    else:
                        first_x.append(x)
                        first_y.append(y)

                plt.figure(figsize=(10, 8))
                plt.scatter(fire_x, fire_y, c='red', s=100, label='Fire Extinguisher', alpha=0.7, edgecolors='k')
                plt.scatter(first_x, first_y, c='green', s=100, label='First Aid Kit', alpha=0.7, edgecolors='k')

                for i, (x, y) in enumerate(zip(fire_x + first_x, fire_y + first_y)):
                    plt.text(x + 0.1, y + 0.1, str(i + 1), fontsize=9)

                total = len(self.inventory)
                fire_count = len(fire_x)
                first_count = len(first_x)

                plt.title(f'Inventory Map (Total: {total} objects)\n'
                          f'Fire Extinguishers: {fire_count} | First Aid Kits: {first_count}',
                          fontsize=14, fontweight='bold')
                plt.xlabel('X Position (m)', fontsize=12)
                plt.ylabel('Y Position (m)', fontsize=12)
                plt.legend()
                plt.grid(True, linestyle='--', alpha=0.5)
                plt.axis('equal')
                plt.tight_layout()
                plt.savefig(self.plot_path, dpi=150)
                plt.close()  # Free memory
                self.get_logger().info(f"Inventory plot saved to {self.plot_path}")
            except Exception as e:
                self.get_logger().error(f"Plot generation failed: {e}")
        elif not MATPLOTLIB_AVAILABLE:
            self.get_logger().warn("matplotlib not installed — skipping plot.")
        else:
            self.get_logger().info("No confirmed objects — skipping plot.")

        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = InventoryAggregator()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()