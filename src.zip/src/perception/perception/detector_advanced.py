#!/usr/bin/env python3
"""
EMERGENCY OBJECT DETECTOR – FINAL OPTIMIZED ACADEMIC RELEASE (v2.4)

FIXES:
  ✅ Tall narrow red objects (aspect > 2.5) now correctly classified as fire_extinguisher
  ✅ Rectangularity no longer overrides strong metric/depth cylinder cues
  ✅ Stricter height-based fallback logic
  ✅ Improved unknown handling for ambiguous cases
  ✅ Maintains robustness to clutter, noise, and robot motion
"""

import rclpy
from rclpy.node import Node
import cv2 as cv
import numpy as np
import math
from rclpy.duration import Duration

from sensor_msgs.msg import Image
from cv_bridge import CvBridge
from tf2_ros import Buffer, TransformListener
from tf2_geometry_msgs import do_transform_pose
from geometry_msgs.msg import Pose, Point, Quaternion, PoseStamped


class EmergencyDetector(Node):
    def __init__(self):
        super().__init__('emergency_detector')

        # Camera intrinsics (from Gazebo depth camera)
        self.fx = 448.6252424876914
        self.fy = 448.6252424876914
        self.cx = 320.5
        self.cy = 240.5

        self.camera_frame = "depth_link"
        self.map_frame = "map"

        self.bridge = CvBridge()
        self.depth_image = None

        self.create_subscription(Image, '/limo/depth_camera_link/image_raw', self.rgb_callback, 10)
        self.create_subscription(Image, '/limo/depth_camera_link/depth/image_raw', self.depth_callback, 10)
        self.detection_pub = self.create_publisher(PoseStamped, '/emergency_detections', 10)

        self.tf_buffer = Buffer()
        self.tf_listener = TransformListener(self.tf_buffer, self)

        # Vision params
        self.min_area = 150
        self.kernel = np.ones((5, 5), np.uint8)

        # Red HSV range
        self.red_low1 = (0, 70, 30)
        self.red_high1 = (10, 255, 255)
        self.red_low2 = (160, 70, 30)
        self.red_high2 = (179, 255, 255)

        # Area thresholds
        self.SMALL_AREA = 550
        self.TINY_AREA = 280

        # Geometric thresholds
        self.RECTANGULARITY_STRONG = 0.78
        self.RECTANGULARITY_GOOD = 0.70
        self.PLANAR_RMSE_STRONG = 0.006
        self.PLANAR_RMSE_GOOD = 0.010
        self.ORTHO_LINE_STRONG = 4

        self.CYL_CIRC_STRONG = 0.70
        self.CYL_SYM_STRONG = 0.80

        # PHYSICAL PRIORS (REAL-WORLD DIMENSIONS)
        self.MIN_FIRE_EXT_HEIGHT = 0.35
        self.MAX_FIRE_EXT_HEIGHT = 0.90
        self.MAX_FIRE_EXT_WIDTH = 0.25

        self.MIN_FIRST_AID_HEIGHT = 0.10
        self.MAX_FIRST_AID_HEIGHT = 0.30
        self.MAX_FIRST_AID_WIDTH = 0.30

        self.UNKNOWN_HEIGHT_MIN = 0.10
        self.UNKNOWN_HEIGHT_MAX = 1.0
        self.UNKNOWN_WIDTH_MAX = 0.35

        # Depth variation thresholds
        self.DEPTH_CV_CYL_MIN = 0.012
        self.DEPTH_CV_CURV_MIN = 0.010

        self.get_logger().info("Emergency Detector – FINAL OPTIMIZED ACADEMIC RELEASE (v2.4)")

    # -------------------- ROS callbacks --------------------

    def depth_callback(self, msg):
        try:
            d = self.bridge.imgmsg_to_cv2(msg, "passthrough")
            d = d.astype(np.float32)
            d[d == 0] = np.nan
            self.depth_image = d
        except Exception as e:
            self.get_logger().warn(f"Depth error: {e}")
            self.depth_image = None

    def rgb_callback(self, msg):
        if self.depth_image is None:
            return

        try:
            frame = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        except Exception as e:
            self.get_logger().warn(f"RGB error: {e}")
            return

        hsv = cv.cvtColor(frame, cv.COLOR_BGR2HSV)

        red_mask = (
            cv.inRange(hsv, self.red_low1, self.red_high1) |
            cv.inRange(hsv, self.red_low2, self.red_high2)
        )
        saturation_mask = cv.inRange(hsv, (0, 120, 80), (180, 255, 255))
        red_mask = cv.bitwise_and(red_mask, saturation_mask)
        red_mask = cv.morphologyEx(red_mask, cv.MORPH_OPEN, self.kernel)

        non_red_mask = cv.inRange(hsv, (0, 50, 30), (180, 255, 255))
        non_red_mask = cv.bitwise_and(non_red_mask, cv.bitwise_not(red_mask))
        non_red_mask = cv.morphologyEx(non_red_mask, cv.MORPH_OPEN, self.kernel)

        self.process_objects(red_mask, frame, is_red=True)
        self.process_objects(non_red_mask, frame, is_red=False)

        cv.imshow("Emergency Detector", frame)
        cv.waitKey(1)

    # -------------------- Geometry helpers --------------------

    def compute_metric_aspect(self, h_m, w_m):
        return h_m / (w_m + 1e-6)

    def contour_curvature_score(self, contour):
        if len(contour) < 10:
            return 0.0
        smooth = cv.approxPolyDP(contour, 1.0, closed=True)
        if len(smooth) < 8:
            return 0.0
        
        angles = []
        n = len(smooth)
        for i in range(n):
            p0 = smooth[i-1][0].astype(float)
            p1 = smooth[i][0].astype(float)
            p2 = smooth[(i+1)%n][0].astype(float)
            v1 = p0 - p1
            v2 = p2 - p1
            norm1, norm2 = np.linalg.norm(v1), np.linalg.norm(v2)
            if norm1 < 1e-3 or norm2 < 1e-3:
                continue
            cos_ang = np.dot(v1/norm1, v2/norm2)
            ang = np.arccos(np.clip(cos_ang, -1, 1))
            angles.append(ang)
        
        high_curv = np.sum(np.array(angles) > np.radians(120))
        return 1.0 - (high_curv / len(angles)) if angles else 0.0

    def corner_flatness(self, contour):
        peri = cv.arcLength(contour, True)
        if peri == 0:
            return 99.0

        area = cv.contourArea(contour)
        if area > 6000:
            eps = 0.008
        elif area > 2000:
            eps = 0.012
        else:
            eps = 0.02

        approx = cv.approxPolyDP(contour, eps * peri, True)
        if len(approx) < 4:
            return 99.0

        angles = []
        n = len(approx)
        for i in range(n):
            p0 = approx[i - 1][0].astype(np.float64)
            p1 = approx[i][0].astype(np.float64)
            p2 = approx[(i + 1) % n][0].astype(np.float64)

            v1 = p0 - p1
            v2 = p2 - p1
            norm1 = np.linalg.norm(v1)
            norm2 = np.linalg.norm(v2)
            if norm1 < 1e-6 or norm2 < 1e-6:
                continue
            v1 /= norm1
            v2 /= norm2

            dot = np.clip(np.dot(v1, v2), -1.0, 1.0)
            ang = np.degrees(np.arccos(dot))
            angles.append(abs(ang - 90.0))

        return float(np.mean(angles)) if angles else 99.0

    def pixel_to_cam(self, u, v, z):
        X = float((u - self.cx) * z / self.fx)
        Y = float((v - self.cy) * z / self.fy)
        Z = float(z)
        return (X, Y, Z)

    def contour_median_depth(self, contour):
        if self.depth_image is None:
            return -1.0
        mask = np.zeros(self.depth_image.shape, dtype=np.uint8)
        cv.drawContours(mask, [contour], -1, 255, -1)
        vals = self.depth_image[mask == 255]
        vals = vals[np.isfinite(vals) & (vals > 0.1)]
        if len(vals) < 50:
            return -1.0
        return float(np.median(vals))

    # -------------------- NEW: Ground & Vertical Analysis --------------------

    def bottom_contact_analysis(self, c, ground_depth):
        if ground_depth is None or self.depth_image is None:
            return 0.0, "unknown"

        x, y, w, h = cv.boundingRect(c)
        bottom_y = y + h - 1
        if bottom_y >= self.depth_image.shape[0]:
            return 0.0, "unknown"

        xs = np.linspace(x, x + w - 1, num=min(w, 50), dtype=int)
        depths = []
        for xi in xs:
            if 0 <= xi < self.depth_image.shape[1]:
                z = self.depth_image[bottom_y, xi]
                if np.isfinite(z) and z > 0:
                    depths.append(z)

        if len(depths) < 5:
            return 0.0, "unknown"

        depths = np.array(depths)
        tol = 0.02
        near_ground = np.abs(depths - ground_depth) <= tol
        contact_ratio = np.mean(near_ground)

        if contact_ratio > 0.6:
            contact_type = "flat"
        elif contact_ratio > 0.2:
            contact_type = "point"
        else:
            contact_type = "none"

        return float(contact_ratio), contact_type

    def vertical_continuity_score(self, cx, cy, w, h, depth_center):
        if self.depth_image is None:
            return 0, False

        H = self.depth_image.shape[0]
        margin = max(1, min(h // 8, 5))
        y_start = max(0, cy - h // 2 + margin)
        y_end = min(H, cy + h // 2 - margin)
        ys = np.arange(y_start, y_end)

        if len(ys) < 6:
            return 0, True

        depths = []
        for yi in ys:
            z = self.depth_image[yi, cx] if 0 <= cx < self.depth_image.shape[1] else np.nan
            depths.append(float(z) if np.isfinite(z) and z > 0 else np.nan)

        depths = np.array(depths)
        valid = ~np.isnan(depths)
        if np.sum(valid) < 4:
            return 0, True

        valid_idx = np.where(valid)[0]
        if len(valid_idx) < 2:
            return 0, True
        filled = np.interp(np.arange(len(depths)), valid_idx, depths[valid_idx])
        
        diffs = np.abs(np.diff(filled))
        disc_thresh = 0.03
        discontinuities = np.sum(diffs > disc_thresh)
        is_continuous = discontinuities <= 1

        return int(discontinuities), is_continuous

    # -------------------- Depth/geometry helpers --------------------

    def compute_depth_cv(self, contour):
        if self.depth_image is None:
            return 0.0
        mask = np.zeros(self.depth_image.shape, dtype=np.uint8)
        cv.drawContours(mask, [contour], -1, 255, -1)
        vals = self.depth_image[mask == 255]
        vals = vals[np.isfinite(vals)]
        vals = vals[vals > 0]
        if len(vals) < 30:
            return 0.0
        q75, q25 = np.percentile(vals, [75, 25])
        iqr = q75 - q25
        vals = vals[(vals >= q25 - 1.5 * iqr) & (vals <= q75 + 1.5 * iqr)]
        if len(vals) < 10:
            return 0.0
        mean = float(np.mean(vals))
        std = float(np.std(vals))
        return std / mean if mean > 1e-6 else 0.0

    def radial_depth_monotonicity(self, cx, cy, r_min=2, r_max=18, step=1, n_angles=12):
        if self.depth_image is None:
            return False
        H, W = self.depth_image.shape
        mask_around = np.zeros((H, W), dtype=np.uint8)
        cv.circle(mask_around, (int(cx), int(cy)), 10, 255, -1)
        object_pixels = self.depth_image[mask_around == 255]
        object_pixels = object_pixels[np.isfinite(object_pixels) & (object_pixels > 0)]
        adaptive_r_max = max(8, min(20, int(25 / np.mean(object_pixels)))) if len(object_pixels) > 0 else 12
        angles = np.linspace(0, 2*np.pi, n_angles, endpoint=False)
        good_rays = 0
        valid_rays = 0
        for a in angles:
            samples = []
            for r in range(r_min, adaptive_r_max, step):
                px = int(cx + r * math.cos(a))
                py = int(cy + r * math.sin(a))
                if 0 <= px < W and 0 <= py < H:
                    z = self.depth_image[py, px]
                    if np.isfinite(z) and z > 0:
                        samples.append(float(z))
            if len(samples) >= 3:
                valid_rays += 1
                overall_increasing = samples[-1] >= samples[0]
                violations = sum(1 for i in range(len(samples)-1) if samples[i] > samples[i+1])
                mostly_monotonic = violations <= len(samples) * 0.3
                if overall_increasing and mostly_monotonic:
                    good_rays += 1
        required_ratio = 0.5 if valid_rays >= 8 else 0.6 if valid_rays >= 5 else 0.7
        return valid_rays > 0 and (good_rays / valid_rays) >= required_ratio

    def get_depth_profile(self, c):
        mask = np.zeros(self.depth_image.shape, dtype=np.uint8)
        cv.drawContours(mask, [c], -1, 255, -1)
        depth_vals = self.depth_image[mask == 255]
        depth_vals = depth_vals[np.isfinite(depth_vals) & (depth_vals > 0)]
        if len(depth_vals) < 15:
            return {'is_flat': False, 'depth_cv': 0.0, 'range_ratio': 1.0}
        depth_std = np.std(depth_vals)
        depth_mean = np.mean(depth_vals)
        depth_cv = depth_std / depth_mean if depth_mean > 0 else 0.0
        depth_range = np.max(depth_vals) - np.min(depth_vals)
        depth_range_ratio = depth_range / depth_mean if depth_mean > 0 else 1.0
        is_flat = (depth_cv < 0.02) and (depth_range_ratio < 0.12)
        return {'is_flat': is_flat, 'depth_cv': depth_cv, 'range_ratio': depth_range_ratio}

    def estimate_ground_plane(self, c):
        if self.depth_image is None:
            return None
        x, y, w, h = cv.boundingRect(c)
        buffer = max(15, min(w, h) // 3)
        x1, y1 = max(0, x - buffer), max(0, y - buffer)
        x2, y2 = min(self.depth_image.shape[1], x + w + buffer), min(self.depth_image.shape[0], y + h + buffer)
        surrounding = self.depth_image[y1:y2, x1:x2]
        surrounding = surrounding[np.isfinite(surrounding) & (surrounding > 0)]
        if len(surrounding) < 80:
            return None
        q75, q25 = np.percentile(surrounding, [75, 25])
        iqr = q75 - q25
        surrounding = surrounding[(surrounding >= q25 - 1.5 * iqr) & (surrounding <= q75 + 1.5 * iqr)]
        if len(surrounding) < 30:
            return None
        ground_depth = np.median(surrounding)
        return ground_depth

    def compute_depth_symmetry(self, cx, cy, margin=10):
        if self.depth_image is None:
            return 0.0
        H, W = self.depth_image.shape
        directions = [(1, 0), (0, 1), (1, 1), (1, -1)]
        symmetry_scores = []
        for dx, dy in directions:
            pos_samples, neg_samples = [], []
            for r in range(1, margin + 1):
                px, py = int(cx + r * dx), int(cy + r * dy)
                if 0 <= px < W and 0 <= py < H:
                    z = self.depth_image[py, px]
                    if np.isfinite(z) and z > 0:
                        pos_samples.append(z)
            for r in range(1, margin + 1):
                px, py = int(cx - r * dx), int(cy - r * dy)
                if 0 <= px < W and 0 <= py < H:
                    z = self.depth_image[py, px]
                    if np.isfinite(z) and z > 0:
                        neg_samples.append(z)
            if len(pos_samples) > 0 and len(neg_samples) > 0:
                min_len = min(len(pos_samples), len(neg_samples))
                if min_len >= 3:
                    pos = np.array(pos_samples[:min_len]) - np.mean(pos_samples[:min_len])
                    neg = np.array(neg_samples[:min_len]) - np.mean(neg_samples[:min_len])
                    if np.std(pos) > 0 and np.std(neg) > 0:
                        corr = np.corrcoef(pos, neg)[0, 1]
                        symmetry_scores.append(abs(corr))
        return float(np.mean(symmetry_scores)) if symmetry_scores else 0.0

    def depth_analysis(self, x, y, w, h, cx, cy):
        H, W = self.depth_image.shape
        depth_center = -1.0
        if not (0 <= cx < W and 0 <= cy < H):
            return False, False, depth_center, (0.0, 0.0, 0.0), 0.0, 0.0, False
        zc = self.depth_image[cy, cx]
        if not (np.isfinite(zc) and zc > 0):
            return False, False, depth_center, (0.0, 0.0, 0.0), 0.0, 0.0, False
        depth_center = float(zc)
        object_size = max(w, h)
        if depth_center < 1.0:
            margin = max(1, min(object_size // 15, 4))
        elif depth_center < 2.0:
            margin = max(2, min(object_size // 10, 6))
        else:
            margin = max(3, min(object_size // 8, 8))
        xs_h = np.arange(x + margin, x + w - margin)
        depths_h = []
        for xi in xs_h:
            d = self.depth_image[cy, xi] if 0 <= xi < W else np.nan
            depths_h.append(float(d) if np.isfinite(d) and d > 0 else np.nan)
        depths_h = np.array(depths_h)
        valid_h = ~np.isnan(depths_h)
        if np.sum(valid_h) < 6:
            return True, False, depth_center, self.pixel_to_cam(cx, cy, depth_center), 0.0, 0.0, False
        xs_h_valid = xs_h[valid_h] - cx
        denom = np.max(np.abs(xs_h_valid))
        xs_h_norm = xs_h_valid / denom if denom > 0 else xs_h_valid
        depths_h_valid = depths_h[valid_h]
        if len(depths_h_valid) > 10:
            q75, q25 = np.percentile(depths_h_valid, [75, 25])
            iqr = q75 - q25
            keep = (depths_h_valid >= q25 - 1.5 * iqr) & (depths_h_valid <= q75 + 1.5 * iqr)
            xs_h_norm = xs_h_norm[keep]
            depths_h_valid = depths_h_valid[keep]
        try:
            coeffs_h = np.polyfit(xs_h_norm, depths_h_valid, 2)
            curvature_h = abs(coeffs_h[0])
        except Exception:
            curvature_h = 0.0
        ys_v = np.arange(y + margin, y + h - margin)
        depths_v = []
        for yi in ys_v:
            d = self.depth_image[yi, cx] if 0 <= yi < H else np.nan
            depths_v.append(float(d) if np.isfinite(d) and d > 0 else np.nan)
        depths_v = np.array(depths_v)
        valid_v = ~np.isnan(depths_v)
        if np.sum(valid_v) < 6:
            return True, False, depth_center, self.pixel_to_cam(cx, cy, depth_center), curvature_h, 0.0, False
        ys_v_valid = ys_v[valid_v] - cy
        denom = np.max(np.abs(ys_v_valid))
        ys_v_norm = ys_v_valid / denom if denom > 0 else ys_v_valid
        depths_v_valid = depths_v[valid_v]
        if len(depths_v_valid) > 10:
            q75, q25 = np.percentile(depths_v_valid, [75, 25])
            iqr = q75 - q25
            keep = (depths_v_valid >= q25 - 1.5 * iqr) & (depths_v_valid <= q75 + 1.5 * iqr)
            ys_v_norm = ys_v_norm[keep]
            depths_v_valid = depths_v_valid[keep]
        try:
            coeffs_v = np.polyfit(ys_v_norm, depths_v_valid, 2)
            curvature_v = abs(coeffs_v[0])
        except Exception:
            curvature_v = 0.0
        object_area = w * h
        if depth_center < 1.0:
            base_threshold = max(0.0002, 0.0008 / depth_center)
            if object_area < 400:
                base_threshold *= 0.7
        elif depth_center < 2.0:
            base_threshold = max(0.0003, 0.0010 / depth_center)
            if object_area < 600:
                base_threshold *= 0.8
        else:
            base_threshold = max(0.0005, 0.0018 / depth_center)
            if object_area < 800:
                base_threshold *= 0.85
        is_cylinder = (
            (curvature_h > base_threshold and not curvature_v > base_threshold) or
            (curvature_v > base_threshold and not curvature_h > base_threshold)
        )
        is_curved = (curvature_h > base_threshold) or (curvature_v > base_threshold)
        return True, is_curved, depth_center, self.pixel_to_cam(cx, cy, depth_center), curvature_h, curvature_v, is_cylinder

    def rotated_rect_features(self, contour):
        area = cv.contourArea(contour)
        rect = cv.minAreaRect(contour)
        (rw, rh) = rect[1]
        rect_area = float(rw * rh) if rw > 1e-6 and rh > 1e-6 else 0.0
        if rect_area <= 1e-6:
            return 0.0, 999.0
        rectangularity = float(np.clip(area / rect_area, 0.0, 1.0))
        rect_aspect = float(max(rw, rh) / max(min(rw, rh), 1e-6))
        return rectangularity, rect_aspect

    def depth_planarity_rmse(self, contour, sample_cap=900):
        if self.depth_image is None:
            return 1.0, False
        H, W = self.depth_image.shape
        mask = np.zeros((H, W), dtype=np.uint8)
        cv.drawContours(mask, [contour], -1, 255, -1)
        ys, xs = np.where(mask == 255)
        if len(xs) < 50:
            return 1.0, False
        if len(xs) > sample_cap:
            idx = np.random.choice(len(xs), sample_cap, replace=False)
            xs, ys = xs[idx], ys[idx]
        zs = self.depth_image[ys, xs]
        valid = np.isfinite(zs) & (zs > 0)
        xs, ys, zs = xs[valid].astype(np.float32), ys[valid].astype(np.float32), zs[valid].astype(np.float32)
        if len(zs) < 40:
            return 1.0, False
        q75, q25 = np.percentile(zs, [75, 25])
        iqr = q75 - q25
        keep = (zs >= q25 - 1.5 * iqr) & (zs <= q75 + 1.5 * iqr)
        xs, ys, zs = xs[keep], ys[keep], zs[keep]
        if len(zs) < 30:
            return 1.0, False
        A = np.stack([xs, ys, np.ones_like(xs)], axis=1)
        try:
            coeff, *_ = np.linalg.lstsq(A, zs, rcond=None)
            z_hat = A @ coeff
            residual = zs - z_hat
            rmse = float(np.sqrt(np.mean(residual * residual)))
            return rmse, True
        except Exception:
            return 1.0, False

    def orthogonal_line_score(self, roi_bgr):
        if roi_bgr is None or roi_bgr.size == 0:
            return 0
        gray = cv.cvtColor(roi_bgr, cv.COLOR_BGR2GRAY)
        edges = cv.Canny(gray, 70, 170)
        lines = cv.HoughLinesP(edges, 1, np.pi / 180, threshold=35,
                               minLineLength=max(12, min(roi_bgr.shape[0], roi_bgr.shape[1]) // 4),
                               maxLineGap=6)
        if lines is None:
            return 0
        angles = []
        for l in lines[:, 0]:
            x1, y1, x2, y2 = l
            dx = x2 - x1
            dy = y2 - y1
            if abs(dx) + abs(dy) < 8:
                continue
            ang = math.degrees(math.atan2(dy, dx))
            ang = (ang + 180.0) % 180.0
            angles.append(ang)
        if len(angles) < 3:
            return 0
        angles = np.array(angles, dtype=np.float32)
        bins = np.linspace(0, 180, 19)
        hist, _ = np.histogram(angles, bins=bins)
        top = np.argsort(hist)[::-1]
        b1 = top[0]
        b2 = top[1] if len(top) > 1 else top[0]
        a1 = (bins[b1] + bins[b1 + 1]) * 0.5
        a2 = (bins[b2] + bins[b2 + 1]) * 0.5
        diff = abs(a1 - a2)
        diff = min(diff, 180.0 - diff)
        ortho = 80.0 <= diff <= 100.0
        score = int(hist[b1]) + int(hist[b2]) if ortho else int(hist[b1])
        return score

    # -------------------- Main detection --------------------

    def process_objects(self, mask, frame, is_red):
        contours, _ = cv.findContours(mask, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)

        for c in contours:
            area = cv.contourArea(c)
            if area < self.min_area:
                continue

            peri = cv.arcLength(c, True)
            if peri <= 0:
                continue

            x, y, w, h = cv.boundingRect(c)
            cx, cy = x + w // 2, y + h // 2

            is_tall = h > 1.4 * w

            circularity = 4 * math.pi * area / (peri * peri)
            hull = cv.convexHull(c)
            hull_area = cv.contourArea(hull)
            solidity = area / hull_area if hull_area > 0 else 0

            if area > 6000:
                eps = 0.008
            elif area > 2000:
                eps = 0.012
            else:
                eps = 0.02
            approx = cv.approxPolyDP(c, eps * peri, True)
            corners = len(approx)

            depth_valid, is_curved, depth_center, (X_cam, Y_cam, Z_cam), curvature_h, curvature_v, is_cylinder = \
                self.depth_analysis(x, y, w, h, cx, cy)

            obj_roi = frame[y:y + h, x:x + w]
            edges = cv.Canny(obj_roi, 80, 180)
            edge_count = int(np.sum(edges > 0))

            depth_cv = self.compute_depth_cv(c)
            radial_monotonic = self.radial_depth_monotonicity(cx, cy)
            depth_profile = self.get_depth_profile(c)

            ground_depth = self.estimate_ground_plane(c)

            contact_ratio, contact_type = self.bottom_contact_analysis(c, ground_depth)
            discontinuities, is_vertical_continuous = self.vertical_continuity_score(cx, cy, w, h, depth_center)

            symmetry_score = self.compute_depth_symmetry(cx, cy)

            rectangularity, rect_aspect = self.rotated_rect_features(c)
            planar_rmse, planar_valid = self.depth_planarity_rmse(c)
            ortho_score = self.orthogonal_line_score(obj_roi)

            depth_med = self.contour_median_depth(c)
            depth_for_metric = depth_med if depth_med > 0 else depth_center

            height_m = h * depth_for_metric / self.fy if depth_for_metric > 0 else 0.0
            width_m = w * depth_for_metric / self.fx if depth_for_metric > 0 else 0.0
            metric_aspect = self.compute_metric_aspect(height_m, width_m)

            corner_flat = self.corner_flatness(c)
            curvature_score = self.contour_curvature_score(c)

            label, confidence, reason = self.classify(
                is_red=is_red,
                is_curved=is_curved,
                is_cylinder=is_cylinder,
                circularity=circularity,
                solidity=solidity,
                corners=corners,
                edge_count=edge_count,
                area=area,
                depth_center=depth_center,
                depth_cv=depth_cv,
                radial_monotonic=radial_monotonic,
                depth_profile=depth_profile,
                is_tall=is_tall,
                symmetry_score=symmetry_score,
                rectangularity=rectangularity,
                rect_aspect=rect_aspect,
                planar_rmse=planar_rmse,
                planar_valid=planar_valid,
                ortho_score=ortho_score,
                metric_aspect=metric_aspect,
                corner_flatness=corner_flat,
                ground_depth=ground_depth,
                height_m=height_m,
                width_m=width_m,
                contact_ratio=contact_ratio,
                contact_type=contact_type,
                is_vertical_continuous=is_vertical_continuous,
                discontinuities=discontinuities,
                curvature_score=curvature_score
            )

            camera_pose = Pose(
                position=Point(x=X_cam, y=Y_cam, z=Z_cam),
                orientation=Quaternion(w=1.0)
            )

            try:
                transform = self.tf_buffer.lookup_transform(
                    self.map_frame,
                    self.camera_frame,
                    rclpy.time.Time(),
                    timeout=Duration(seconds=1.0)
                )
                map_pose = do_transform_pose(camera_pose, transform)

                pose_stamped = PoseStamped()
                pose_stamped.header.frame_id = label
                pose_stamped.header.stamp = self.get_clock().now().to_msg()
                pose_stamped.pose = map_pose
                self.detection_pub.publish(pose_stamped)

                color = (0, 0, 255) if label == "fire_extinguisher" else \
                        (0, 255, 0) if label == "first_aid_kit" else \
                        (255, 255, 0)
                cv.rectangle(frame, (x, y), (x + w, y + h), color, 2)
                cv.putText(frame, f"{label} ({confidence:.2f})", (x, y - 25),
                           cv.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

                pos_text = f"X:{map_pose.position.x:.2f} Y:{map_pose.position.y:.2f} Z:{map_pose.position.z:.2f}"
                cv.putText(frame, pos_text, (x, y - 10),
                           cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

                dbg = (f"Z:{depth_center:.2f} H:{height_m:.2f} W:{width_m:.2f} cv:{depth_cv:.3f} "
                       f"rect:{rectangularity:.2f} aspect:{metric_aspect:.2f} "
                       f"cont:{contact_type} disc:{discontinuities}")
                cv.putText(frame, dbg, (x, y + h + 15),
                           cv.FONT_HERSHEY_SIMPLEX, 0.42, (255, 255, 0), 1)

                self.get_logger().info(
                    f"[DET] {label:18} | X:{map_pose.position.x:6.2f} Y:{map_pose.position.y:6.2f} Z:{map_pose.position.z:6.2f} | "
                    f"H:{height_m:.2f}m W:{width_m:.2f}m Circ:{circularity:.2f} Rect:{rectangularity:.2f} "
                    f"Aspect:{metric_aspect:.2f} PlaneRMSE:{planar_rmse:.4f} | {reason}"
                )

            except Exception as e:
                self.get_logger().warn(f"TF2 error: {e}")

    # -------------------- FINAL OPTIMIZED Classification Logic (v2.4) --------------------

    def classify(self, *,
                 is_red, is_curved, is_cylinder, circularity, solidity, corners, edge_count, area,
                 depth_center, depth_cv, radial_monotonic, depth_profile, is_tall,
                 symmetry_score, rectangularity, rect_aspect, planar_rmse, planar_valid, ortho_score,
                 metric_aspect, corner_flatness, ground_depth, height_m, width_m,
                 contact_ratio, contact_type, is_vertical_continuous, discontinuities,
                 curvature_score):

        # --- STEP 0: ABSOLUTE METRIC SIZE REJECTION ---
        if (height_m < self.UNKNOWN_HEIGHT_MIN or 
            height_m > self.UNKNOWN_HEIGHT_MAX or 
            width_m > self.UNKNOWN_WIDTH_MAX):
            return "unknown", 0.95, "Metric size out of physical bounds"

        if depth_center <= 0 or not np.isfinite(depth_center):
            return "unknown", 0.0, "Invalid depth"

        # --- STEP 1: EVIDENCE SCORING (CYLINDER vs BOX) ---
        cylinder_evidence = 0.0
        if radial_monotonic:
            cylinder_evidence += 0.25
        if is_cylinder:
            cylinder_evidence += 0.25
        if curvature_score > 0.6:
            cylinder_evidence += 0.20
        if corner_flatness > 25.0:
            cylinder_evidence += 0.15
        if contact_type == "point":
            cylinder_evidence += 0.15

        box_evidence = 0.0
        if rectangularity >= 0.85:
            box_evidence += 0.30
        if corner_flatness < 8.0:
            box_evidence += 0.25
        if contact_type == "flat":
            box_evidence += 0.20
        if planar_valid and planar_rmse <= 0.012:
            box_evidence += 0.25

        total = cylinder_evidence + box_evidence + 1e-6
        cyl_conf = cylinder_evidence / total
        box_conf = box_evidence / total

        # --- STEP 2: VERTICAL DISCONTINUITY → COMPOSITE? ---
        if discontinuities >= 2:
            if rectangularity > 0.7 or contact_type == "flat":
                return "first_aid_kit", 0.97, "Vertical discontinuities ≥2 → stacked boxes"
            else:
                return "unknown", 0.90, "Vertical discontinuities ≥2 → non-box composite"

        # --- STEP 3: PRIMARY CLASSIFICATION BY HEIGHT + ASPECT + COLOR ---
        # 🔥 FIRE EXTINGUISHER: tall, narrow, red
        if is_red and self.MIN_FIRE_EXT_HEIGHT <= height_m <= self.MAX_FIRE_EXT_HEIGHT and width_m <= self.MAX_FIRE_EXT_WIDTH:
            # Extremely tall/narrow → override rectangularity!
            if metric_aspect > 2.5:
                if depth_cv > 0.008 or curvature_score > 0.5 or radial_monotonic:
                    return "fire_extinguisher", 0.96, "Tall narrow red + depth/curvature cues"
                else:
                    return "fire_extinguisher", 0.88, "Tall narrow red (default to ext.)"
            
            # Moderately tall
            if cyl_conf > 0.55:
                conf = min(0.95, 0.82 + 0.13 * cyl_conf)
                return "fire_extinguisher", conf, "Tall red + cylinder evidence"

        # 🩹 FIRST AID KIT: short, any color
        if self.MIN_FIRST_AID_HEIGHT <= height_m <= self.MAX_FIRST_AID_HEIGHT and width_m <= self.MAX_FIRST_AID_WIDTH:
            if box_conf > 0.55:
                conf = min(0.96, 0.85 + 0.11 * box_conf)
                return "first_aid_kit", conf, "Short + box evidence"

        # --- STEP 4: GROUND CONTACT TIE-BREAKERS ---
        if contact_type == "flat" and height_m < 0.35:
            if rectangularity > 0.75 or (planar_valid and planar_rmse < 0.015):
                return "first_aid_kit", 0.96, "Flat contact + short height"

        if contact_type == "point" and height_m > 0.35 and is_red:
            if cyl_conf > 0.4 or depth_cv > 0.01:
                return "fire_extinguisher", 0.93, "Point contact + tall red"

        # --- STEP 5: NON-RED OBJECTS ---
        if not is_red:
            if self.MIN_FIRST_AID_HEIGHT <= height_m <= self.MAX_FIRST_AID_HEIGHT:
                return "first_aid_kit", 0.92, "Non-red in first aid size range"
            else:
                return "unknown", 0.88, "Non-red outside typical size"

        # --- STEP 6: AMBIGUOUS RED OBJECTS ---
        if is_red and 0.25 < height_m < 0.4 and 0.2 < width_m < 0.3:
            return "unknown", 0.85, "Ambiguous size between classes"

        # --- FINAL FALLBACK: USE HEIGHT AS DECIDER ---
        if height_m <= 0.32:
            return "first_aid_kit", 0.87, "Short object, no strong cylinder evidence"
        else:
            # Tall red object with weak evidence → still likely fire extinguisher
            if is_red:
                return "fire_extinguisher", 0.85, "Tall red object, weak evidence"
            else:
                return "unknown", 0.80, "Tall non-red object"


def main():
    rclpy.init()
    node = EmergencyDetector()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()
        cv.destroyAllWindows()


if __name__ == "__main__":
    main()