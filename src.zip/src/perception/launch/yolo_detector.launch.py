from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package="perception",
            executable="yolo_detector",
            name="yolo_detector",
            output="screen",
            parameters=[{
                "model_path": "/workspaces/cmp9767-robot_project_limo-main/runs/segment/train/weights/best.pt",
                "device": "cuda:0",  # change to "cpu" if needed
                "conf": 0.25,
                "imgsz": 640,
                "show_window": True,
                "rgb_topic": "/limo/depth_camera_link/image_raw",
                "depth_topic": "/limo/depth_camera_link/depth/image_raw",
                "camera_info_topic": "/limo/depth_camera_link/camera_info",
                "target_frame": "limo/depth_camera_link"
            }]
        )
    ])
