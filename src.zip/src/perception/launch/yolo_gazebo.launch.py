"""Launch Gazebo world, spawn test models, run darknet_ros and yolo detector.

Usage (example):
  ros2 launch perception yolo_gazebo.launch.py
"""
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, SetEnvironmentVariable, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from ament_index_python.packages import get_package_share_directory
from launch_ros.actions import Node
import os


def generate_launch_description():
    pkg_share = get_package_share_directory('perception')
    models_path = os.path.join(pkg_share, 'models')

    # Set GAZEBO_MODEL_PATH so spawn_entity and Gazebo find the models
    set_model_path = SetEnvironmentVariable('GAZEBO_MODEL_PATH', LaunchConfiguration('gazebo_model_path', default=models_path + ':' + os.environ.get('GAZEBO_MODEL_PATH', '')))

    # Include the main Gazebo launch (limo world)
    limo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([get_package_share_directory('limo_gazebosim'), '/launch/limo_gazebo_diff.launch.py'])
    )

    # Include darknet_ros launch
    darknet_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([get_package_share_directory('darknet_ros'), '/launch/darknet_ros.launch.py']),
        # set the network param file to our 2-class config in darknet_ros config
        launch_arguments={'network_param_file': get_package_share_directory('darknet_ros') + '/config/yolov3-2cls.yaml'}.items()
    )

    # Spawner and detector nodes
    spawn_node = Node(
        package='perception',
        executable='spawn_models',
        name='spawn_models',
        output='screen'
    )

    yolo_node = Node(
        package='perception',
        executable='yolo_detector',
        name='yolo_detector',
        output='screen'
    )

    ld = LaunchDescription()
    ld.add_action(set_model_path)
    ld.add_action(DeclareLaunchArgument('gazebo_model_path', default_value=models_path, description='Path to local models'))
    ld.add_action(limo_launch)
    ld.add_action(darknet_launch)
    ld.add_action(spawn_node)
    ld.add_action(yolo_node)

    return ld
