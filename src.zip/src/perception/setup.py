from setuptools import setup
from glob import glob
import os

package_name = 'perception'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],

    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),

        ('share/' + package_name,
            ['package.xml']),

        # ✅ INSTALL ALL LAUNCH FILES
        (os.path.join('share', package_name, 'launch'),
            glob('launch/*.launch.py')),

        # ✅ INSTALL GAZEBO MODELS
        (os.path.join('share', package_name, 'models', 'fire_extinguisher'),
            ['models/fire_extinguisher/model.sdf',
             'models/fire_extinguisher/model.config']),

        (os.path.join('share', package_name, 'models', 'first_aid_kit'),
            ['models/first_aid_kit/model.sdf',
             'models/first_aid_kit/model.config']),
    ],

    install_requires=['setuptools'],
    zip_safe=True,

    maintainer='student',
    maintainer_email='student@example.com',
    description='YOLOv8 safety perception for LIMO',
    license='Apache-2.0',

    tests_require=['pytest'],

    # ✅ ENTRY POINTS MUST BE INSIDE setup()
    entry_points={
    'console_scripts': [
        'detector_basic = perception.detector_basic:main',
        'controller_vision = perception.controller_vision:main',
        'yolo_detector = perception.yolo_detector:main',
        'object_localizer = perception.object_localizer:main',
        'detector_advanced = perception.detector_advanced:main',
        'inventory_aggregator = perception.inventory_aggregator:main',
    ],
},

)
