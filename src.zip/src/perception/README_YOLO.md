YOLO integration for Gazebo
==========================

Quick steps to run the 2-class YOLO detector in Gazebo (fire extinguisher & first aid kit):

1) Install the generated cfg into the `darknet_ros` package:

   ./scripts/install_yolo_assets.sh

2) Copy your trained weights to:

   src/darknet_ros/darknet_ros/yolo_network_config/weights/yolov3-2cls_final.weights

3) Build the workspace (colcon build) and source the install setup.

4) Launch the sim, spawner and detector:

   ros2 launch perception yolo_gazebo.launch.py

5) Visualise detection image (box overlay):

   ros2 run rqt_image_view rqt_image_view /yolo/detections_image

6) Inspect bounding boxes topic:

   ros2 topic echo /darknet_ros/bounding_boxes

Notes:
- The `yolov3-2cls.cfg` is copied into the `darknet_ros/yolo_network_config/cfg` directory
  by `./scripts/install_yolo_assets.sh`.
- I added two placeholder models in `src/perception/models` (fire_extinguisher and first_aid_kit).
  Replace the SDF/meshes with higher fidelity models if you have them.
