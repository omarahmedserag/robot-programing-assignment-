from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import PathJoinSubstitution, EnvironmentVariable, TextSubstitution
from launch_ros.substitutions import FindPackageShare


def generate_launch_description():

    world_pkg = FindPackageShare('world')

    world_file = PathJoinSubstitution([
        world_pkg,
        'worlds',
        'my_lab.world'
    ])

    models_path = PathJoinSubstitution([
        world_pkg,
        'models'
    ])

    # ✅ APPEND to existing GAZEBO_MODEL_PATH
    set_gazebo_model_path = SetEnvironmentVariable(
        name='GAZEBO_MODEL_PATH',
        value=[
            EnvironmentVariable('GAZEBO_MODEL_PATH'),
            TextSubstitution(text=':'),
            models_path
        ]
    )

    limo_launch = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            PathJoinSubstitution([
                FindPackageShare('limo_gazebosim'),
                'launch',
                'limo_gazebo_diff.launch.py'
            ])
        ),
        launch_arguments={
            'world': world_file
        }.items()
    )

    return LaunchDescription([
        set_gazebo_model_path,
        limo_launch
    ])
