#1 to launch my world file you can use either commands
1)ros2 launch limo_gazebosim limo_gazebo_diff.launch.py world:=src/rally_obstacle9.world
source /opt/ros/humble/setup.bash
source install/setup.bash
2) ros2 launch world world.launch.py
-------------------------------------------------------------------------------------------------------
#2 run navigation stack with optimized parameters using below command in a new terminal
ros2 launch limo_navigation limo_navigation.launch.py \
  map:=/workspaces/cmp9767-robot_project_limo-main/src/my_map_obstacle2.yaml \
  params_file:=/workspaces/cmp9767-robot_project_limo-main/src/navigation/config/nav2_params.yaml

------------------------------------------------------------------------------------------------------
#3 to run colour and shape detection run the following commands in a new terminal
colcon build --packages-select perception
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 run perception detector_basic

 (important note)the main algorithim is to detect fire extinguisher and first aid kit which can be represented from a real mesh import from gazebosim official site
or from taking a cylinder  and box and modify it to match approximatly the fire extinguisher real dimension as well
as the first aid kit box real dimension.  in addition to that, to classify big boxes, cylinders , and spheres as unknown like any large sized object than the normal fire extinguisher and first aid kit
as an unknown object.
------------------------------------------------------------------------------------------------------------------
#4 run the inventory aggregator in a new terminal 
colcon build --packages-select perception
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 run perception inventory_aggregator
(important note)
the perception node publishes a PoseStamped message for every frame‑level detection, so the same physical object can appear many times as the robot drives past.
 To obtain a one‑entry‑per‑object inventory, a separate InventoryAggregator node performs spatial and temporal de‑duplication.
first, any new detection whose pose lies within an association radius of 2.2 m of an already confirmed object is discarded.
 If the detection does not match an existing object, it is assigned to the nearest candidate cluster whose mean pose lies within a confirmation radius of 1.65 m; otherwise, a new candidate is created.
 Each candidate stores all incoming poses and a class‑vote histogram. When the number of observations in a cluster reaches min_observations = 5
 ,and the most frequent class accounts for at least class_dominance = 0.7 of the votes,the candidate is promoted to a confirmed inventory object and removed from the candidate list.
In addition, detections are only considered if the object lies within a distance gate of 2.2 m from the robot, 
computed using the current robot pose from TF. This constraint filters out far‑range, low‑quality observations where depth noise and partial views tended to cause misclassifications;
---------------------------------------------------------------------------------------------------------

#5 run the waypoint navigation
colcon build --packages-select navigation
source /opt/ros/humble/setup.bash
source install/setup.bash
ros2 run navigation waypoint_nav
-----------------------------------------------------------------------------------------------------

The waypoint tour in waypoint_nav.py was built from recorded /goal_pose commands to provide complete coverage of the environment rather than choosing  any single path. 
The sequence first explores the north‑east corridor and then traces the top, left, and bottom boundaries of the map, passing within a few metres of all fourteen ground‑truth emergency objects (with the positions given from gazebo simulation ), 
before traversing several interior waypoints and returning to the origin. The selected positions allowed the robot to search and find for each fire extinguisher and first aid kit is observed at least once, often from multiple viewpoints, 
which is important for the temporal voting in the inventory aggregator and for evaluating detection, counting, and pose accuracy over the complete navigation tour.

i have a added a word file(color and shape detector metric results) showing the test results which are based on experimental trials with different distance thresholds parameter to test the accuracy,precision , and f1 score of the detector.
also i have added a yolo train results  foldermeasuring the accuracy of the yolo model .
