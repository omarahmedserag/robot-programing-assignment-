import os

from ament_index_python.packages import get_package_share_directory

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():

    pkg_dir = get_package_share_directory('navigation')

    namespace   = LaunchConfiguration('namespace')
    use_sim_time = LaunchConfiguration('use_sim_time')
    autostart   = LaunchConfiguration('autostart')
    map_yaml    = LaunchConfiguration('map')
    params_file = LaunchConfiguration('params_file')
    use_rviz    = LaunchConfiguration('use_rviz')

    # Correct lifecycle nodes for Nav2
    lifecycle_nodes = [
        'controller_server',
        'planner_server',
        'behavior_server',
        'bt_navigator',
        'waypoint_follower'
    ]

    # Map server should be in localization lifecycle, not navigation
    localization_lifecycle_nodes = ['map_server', 'amcl']

    declare_namespace = DeclareLaunchArgument(
        'namespace',
        default_value='',
        description='Top-level namespace'
    )

    declare_use_sim_time = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',  # Changed from 'true' unless you're in simulation
        description='Use simulation clock'
    )

    declare_autostart = DeclareLaunchArgument(
        'autostart',
        default_value='true',
        description='Automatically startup Nav2'
    )

    declare_map = DeclareLaunchArgument(
        'map',
        default_value=os.path.join(pkg_dir, 'maps', 'simple_map.yaml'),
        description='Full path to map yaml file'
    )

    declare_params_file = DeclareLaunchArgument(
        'params_file',
        default_value=os.path.join(pkg_dir, 'config', 'nav2_params.yaml'),
        description='Full path to the Nav2 parameters file'
    )

    declare_use_rviz = DeclareLaunchArgument(
        'use_rviz',
        default_value='true',
        description='Whether to launch RVIZ'
    )

    # Launch localization (map_server + AMCL)
    launch_localization = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_dir, 'launch', 'limo_localization.launch.py')
        ),
        launch_arguments={
            'namespace': namespace,
            'use_sim_time': use_sim_time,
            'map': map_yaml,
            'params_file': params_file,
            'use_rviz': use_rviz,
            'autostart': autostart  # Important: pass autostart to localization too
        }.items()
    )

    # Launch controller (navigation stack)
    launch_controller = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_dir, 'launch', 'limo_controller.launch.py')
        ),
        launch_arguments={
            'namespace': namespace,
            'use_sim_time': use_sim_time,
            'params_file': params_file,  # Important: pass params_file to controller
            'autostart': autostart
        }.items()
    )

    # Navigation lifecycle manager (handles controller, planner, etc.)
    lifecycle_mgr_navigation = Node(
        package='nav2_lifecycle_manager',
        executable='lifecycle_manager',
        name='lifecycle_manager_navigation',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            {'autostart': autostart},
            {'node_names': lifecycle_nodes}
        ]
    )

    ld = LaunchDescription()

    ld.add_action(declare_namespace)
    ld.add_action(declare_use_sim_time)
    ld.add_action(declare_autostart)
    ld.add_action(declare_map)
    ld.add_action(declare_params_file)
    ld.add_action(declare_use_rviz)

    # Launch in correct order: localization first, then navigation
    ld.add_action(launch_localization)
    # Wait a moment for localization to start
    # In real launch, we'd use event handlers, but this is simplified
    ld.add_action(launch_controller)
    ld.add_action(lifecycle_mgr_navigation)

    return ld
